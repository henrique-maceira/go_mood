export async function buscarSugestoes(dados) {
  const response = await fetch("http://localhost:3000/api/sugestoes", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dados),
  });

  if (!response.ok) {
    throw new Error("Erro ao buscar sugestões");
  }

  const json = await response.json();
  return json.resposta; // ou json.resultado, dependendo do nome no backend
}
